from typing import Dict, Any

def get_available_odds() -> Dict[str, Any]:
    """
    Placeholder for live odds.

    V1 intentionally does not scrape or invent odds.
    Add a licensed odds API, DarkHorse export/API, or another permitted source here.

    Return shape:
    {
      "Team A @ Team B": {
        "BetMGM": "-120",
        "DraftKings": "-115",
        ...
      }
    }
    """
    return {}
