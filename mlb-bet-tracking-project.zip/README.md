# MLB Bet Tracking Automation

This project writes 5 MLB betting picks into a Google Sheet every day at noon Eastern.

## Current V1 features

- Daily GitHub Actions automation
- Google Sheets integration
- 5 MLB picks per day
- No player props
- Moneyline / Run Line / Total only
- Best Bet flag
- Confidence ratings
- Columns for BetMGM, DraftKings, Fanatics, PolymarketUS, and Kalshi
- Odds fields are left blank unless a permitted odds source is added

## Required GitHub Secrets

Go to Repository Settings -> Secrets and variables -> Actions -> New repository secret.

Add:

- `OPENAI_API_KEY`
- `SPREADSHEET_ID`
- `GOOGLE_SERVICE_ACCOUNT_JSON`

## Google Sheets access

1. Create a Google Cloud service account.
2. Create a JSON key for that service account.
3. Copy the full JSON into the `GOOGLE_SERVICE_ACCOUNT_JSON` GitHub secret.
4. Share your Google Sheet with the service account email as Editor.
5. Set `SPREADSHEET_ID` to your sheet ID.

For your sheet, the ID is:

`1YF7gwPA1n4R-NMIhQDE9CPkMn8w4DROngt6DIRb2o-w`

## Manual test

In GitHub:

1. Go to Actions.
2. Select Daily MLB Picks.
3. Click Run workflow.

## Phase 2

Add real odds integration from:
- DarkHorse Odds API/export, if available
- Licensed odds API
- Kalshi / Polymarket permitted data access
- Result grading and dashboard updates
