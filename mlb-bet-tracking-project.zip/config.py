import os

SPREADSHEET_ID = os.environ.get("SPREADSHEET_ID", "")
SHEET_NAME = os.environ.get("SHEET_NAME", "Daily Picks")
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")

# Optional for later live odds integration
ODDS_API_KEY = os.environ.get("ODDS_API_KEY", "")
