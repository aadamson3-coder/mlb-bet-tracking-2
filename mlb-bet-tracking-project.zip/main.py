from datetime import datetime
from zoneinfo import ZoneInfo

from google_sheets import append_rows
from odds import get_available_odds
from predictor import generate_picks

def main():
    odds_data = get_available_odds()
    picks = generate_picks(odds_data)
    timestamp = datetime.now(ZoneInfo("America/New_York")).isoformat()

    rows = []
    for p in picks:
        rows.append([
            timestamp,
            p.get("date", ""),
            p.get("game", ""),
            p.get("pick", ""),
            p.get("bet_type", ""),
            p.get("betmgm", ""),
            p.get("draftkings", ""),
            p.get("fanatics", ""),
            p.get("polymarketus", ""),
            p.get("kalshi", ""),
            p.get("best_odds", ""),
            p.get("best_source", ""),
            p.get("confidence", ""),
            "Yes" if p.get("best_bet") else "",
            p.get("rationale", ""),
            "",
            "",
            ""
        ])

    append_rows(rows)
    print(f"Added {len(rows)} picks.")

if __name__ == "__main__":
    main()
