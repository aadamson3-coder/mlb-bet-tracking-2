def grade_results():
    """
    Phase 2 placeholder.

    Later this will fetch final MLB scores and grade:
    - Moneyline
    - Run Line
    - Totals
    Then update Result, Units, Profit/Loss, bankroll, and dashboard.
    """
    raise NotImplementedError("Result grading will be added in Phase 2.")
