import json
import os
from typing import List

import gspread
from google.oauth2.service_account import Credentials

from config import SPREADSHEET_ID, SHEET_NAME

HEADERS = [
    "Timestamp", "Date", "Game", "Pick", "Bet Type",
    "BetMGM", "DraftKings", "Fanatics", "PolymarketUS", "Kalshi",
    "Best Odds", "Best Source", "Confidence", "Best Bet",
    "Rationale", "Result", "Units", "Profit/Loss"
]

def get_worksheet():
    service_account_json = os.environ["GOOGLE_SERVICE_ACCOUNT_JSON"]
    service_account_info = json.loads(service_account_json)

    scopes = [
        "https://www.googleapis.com/auth/spreadsheets",
        "https://www.googleapis.com/auth/drive"
    ]

    creds = Credentials.from_service_account_info(service_account_info, scopes=scopes)
    client = gspread.authorize(creds)
    spreadsheet = client.open_by_key(SPREADSHEET_ID)

    try:
        worksheet = spreadsheet.worksheet(SHEET_NAME)
    except gspread.WorksheetNotFound:
        worksheet = spreadsheet.add_worksheet(title=SHEET_NAME, rows=1000, cols=len(HEADERS))

    current_headers = worksheet.row_values(1)
    if current_headers != HEADERS:
        worksheet.clear()
        worksheet.append_row(HEADERS)
        worksheet.freeze(rows=1)

    return worksheet

def append_rows(rows: List[List[str]]):
    worksheet = get_worksheet()
    worksheet.append_rows(rows, value_input_option="USER_ENTERED")
