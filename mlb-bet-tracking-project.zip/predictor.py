import json
import os
from datetime import datetime
from zoneinfo import ZoneInfo
from typing import List, Dict, Any

from openai import OpenAI
from config import OPENAI_MODEL

def generate_picks(odds_data: Dict[str, Any]) -> List[Dict[str, Any]]:
    today = datetime.now(ZoneInfo("America/New_York")).strftime("%Y-%m-%d")
    client = OpenAI(api_key=os.environ["OPENAI_API_KEY"])

    prompt = f'''
Generate exactly 5 MLB betting picks for {today}.

Rules:
- No player props.
- Only Moneyline, Run Line, or Total.
- Mark exactly one pick as best_bet=true.
- Confidence must be 1 to 5.
- Do not invent sportsbook odds.
- Use odds only from the supplied odds_data. If none are supplied, leave odds fields blank.
- Return ONLY valid JSON array. No markdown.

odds_data:
{json.dumps(odds_data)}

Schema:
[
  {{
    "date": "YYYY-MM-DD",
    "game": "Team @ Team",
    "pick": "Pick text",
    "bet_type": "Moneyline | Run Line | Total",
    "betmgm": "",
    "draftkings": "",
    "fanatics": "",
    "polymarketus": "",
    "kalshi": "",
    "best_odds": "",
    "best_source": "",
    "confidence": 4.5,
    "best_bet": false,
    "rationale": "Brief reason"
  }}
]
'''

    response = client.responses.create(
        model=OPENAI_MODEL,
        input=prompt
    )

    text = response.output_text.strip()
    return json.loads(text)
